<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
          <div class="box">
            <div class="box-header">
              <h3 class="box-title">List Anggota Kelompok</h3>
            </div>
            <div class="row">
                        <div class="col-xs-5 col-xs-offset-1">

                            <a class="btn btn-sm btn-default" href="<?php echo $content['back_url']?>" title="Edit">
                            <i class="glyphicon glyphicon-arrow-left"></i> Back
                            </a>
                        </div>
                    </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" style="width:100%" class="table table-bordered table-striped display nowrap">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Kode Kelompok</th>
                  <th>Anggota</th>
                  <th>Email</th>
                  <th>HP</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
                <tfoot>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
  