<!-- Mainly scripts -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/jquery-3.1.1.min.js"></script>
<!-- jQuery UI -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jquery-ui/jquery-ui.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Flot -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.spline.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.pie.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.symbol.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/flot/jquery.flot.time.js"></script>

<!-- Peity -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/peity/jquery.peity.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/demo/peity-demo.js"></script>

<!-- Custom and plugin javascript -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/inspinia.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/pace/pace.min.js"></script>

<!-- Jvectormap -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>

<!-- EayPIE -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/easypiechart/jquery.easypiechart.js"></script>
<!-- Sparkline -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/sparkline/jquery.sparkline.min.js"></script>

<!-- Sparkline demo data  -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/demo/sparkline-demo.js"></script>

<!-- Typehead -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/typehead/bootstrap3-typeahead.min.js"></script>

<!-- Datatables -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/dataTables/datatables.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/sweetalert/sweetalert.min.js"></script>
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jasny/jasny-bootstrap.min.js"></script>

<!-- Chosen -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/chosen/chosen.jquery.js"></script>

<!-- JSKnob -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jsKnob/jquery.knob.js"></script>

<!-- Input Mask-->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/jasny/jasny-bootstrap.min.js"></script>

<!-- Data picker -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/datapicker/bootstrap-datepicker.js"></script>

<!-- NouSlider -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/nouslider/jquery.nouislider.min.js"></script>

<!-- Switchery -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/switchery/switchery.js"></script>

<!-- IonRangeSlider -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

<!-- iCheck -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/iCheck/icheck.min.js"></script>

<!-- MENU -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/metisMenu/jquery.metisMenu.js"></script>

<!-- Color picker -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>

<!-- Clock picker -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/clockpicker/clockpicker.js"></script>

<!-- Image cropper -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/cropper/cropper.min.js"></script>

<!-- Date range use moment.js same as full calendar plugin -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/fullcalendar/moment.min.js"></script>

<!-- Date range picker -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/daterangepicker/daterangepicker.js"></script>

<!-- Select2 -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/select2/select2.full.min.js"></script>

<!-- TouchSpin -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/touchspin/jquery.bootstrap-touchspin.min.js"></script>

<!-- Tags Input -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>

<!-- Dual Listbox -->
<script src="<?php echo base_url('assets/ass_admin/templates/'); ?>js/plugins/dualListbox/jquery.bootstrap-duallistbox.js"></script>