<div class="footer">
    <div>
        <strong>Copyright</strong> Badan Amalan Islam Matholi'ul Anwar Universitas Dian Nuswantoro &copy; 2018
    </div>
</div>