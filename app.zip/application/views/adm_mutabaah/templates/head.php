<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mutabaah - Admin</title>
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>font-awesome/css/font-awesome.css" rel="stylesheet">

    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/iCheck/custom.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/chosen/bootstrap-chosen.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/colorpicker/bootstrap-colorpicker.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/cropper/cropper.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/switchery/switchery.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/nouslider/jquery.nouislider.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/datapicker/datepicker3.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/clockpicker/clockpicker.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/daterangepicker/daterangepicker-bs3.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/select2/select2.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/dualListbox/bootstrap-duallistbox.min.css" rel="stylesheet">

    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/animate.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/style.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/dataTables/datatables.min.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/sweetalert/sweetalert.css" rel="stylesheet">
    <link href="<?php echo base_url('assets/ass_admin/templates/'); ?>css/plugins/jasny/jasny-bootstrap.min.css" rel="stylesheet">
</head>